var username;
var message;
username = 'Molly';
message = 'See our upcoming range';

var elName = document.getElementByID('name');
elName.textContent = username;
var elNote = document.getElementByID('note');
elNote.textContent = message;
