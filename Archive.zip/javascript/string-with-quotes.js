var title;
var message; 
title = "Molly's Special Offers";
message = '<a href=\"safe.html\">25% off!</a>';

var elTitle = document.getElementById('title');
elTitle.innerHTML = title;
var elNote = document.getElementById('note');
elNote.innerHTML = message;