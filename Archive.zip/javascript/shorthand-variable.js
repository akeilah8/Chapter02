var price = 5;
var quantity = 14;
var total = price * quantity;

//Write total into the element with id of cost
var el = document.getElementById('cost');
el.textContent = '$' + total;